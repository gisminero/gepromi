# -*- coding: utf-8 -*-
{
    'name': "GeProMi Manifestaciones Pevio",

    'summary': """
        Condiciones previas a la instalacione del modulo manifestaciones""",

    'description': """
        Condiciones prevas solo para la primera version del modulo manifestaciones
        la misma se encuentra instalada en la provincia de Jujuy
    """,

    'author': "Gis Minero Nacional",
    'website': "http://www.gismineronacional.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'gepromi', 'tarea'],

    # always loaded
    'data': [
        'security/gepromi_security.xml',
        'security/ir.model.access.csv',
        'views/views.xml',
    ],
    # only loaded in demonstration mode
    #'demo': [
        #'demo/demo.xml',
    #],
    'application': True,
    'auto_install': False,
}