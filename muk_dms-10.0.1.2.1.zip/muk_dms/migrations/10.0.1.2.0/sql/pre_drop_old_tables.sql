DROP TABLE muk_dms_config_settings;
DROP TABLE muk_dms_access;
