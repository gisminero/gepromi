# -*- coding: utf-8 -*-

from odoo import models, fields, api

class notificaciones_pre(models.Model):
    _name = 'tarea.plazo'
    _inherit = "tarea.plazo"


class gepromi(models.Model):
    _name = 'gepromi.gepromi'
    _inherit = "gepromi.gepromi"
